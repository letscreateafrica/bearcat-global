// Public aggregate counter. No visitor identity, IP, cookie or event log is stored.
export function currentOpportunityHtml(html, now = new Date()) {
  const today = now.toISOString().slice(0, 10);
  let count = 0;
  const filtered = html.replace(/<article\b[^>]*\bdata-opportunity\b[^>]*>[\s\S]*?<\/article>/g, card => {
    const review = card.match(/data-review-due="([^"]+)"/)?.[1];
    const deadline = card.match(/data-deadline="([^"]*)"/)?.[1];
    if (!review || today >= review || (deadline && today >= deadline)) return '';
    count++;
    return card;
  });
  if (!html.includes('id="opp-result-count"')) return filtered;
  return filtered.replace('<p role="status" id="opp-result-count" class="small"></p>', '<p role="status" id="opp-result-count" class="small">' + count + ' currently verified items. Use the filters to narrow your selection.</p>')
    .replace('id="opp-empty" class="panel" hidden', 'id="opp-empty" class="panel"' + (count ? ' hidden' : ''));
}
export function createWorker(assets) {
  const jsonHeaders = { 'Cache-Control': 'no-store', 'Content-Type': 'application/json' };
  return {
    async fetch(request, env) {
      const url = new URL(request.url);
      let pathname;
      try { pathname = decodeURIComponent(url.pathname); } catch { return new Response('Bad request', { status: 400 }); }
      const homepage = pathname === '/' || pathname === '/index.html';
      let assetPath = pathname.endsWith('/') ? pathname + 'index.html' : pathname;
      if (!assets[assetPath] && assets[assetPath + '/index.html']) assetPath += '/index.html';
      const asset = assets[assetPath];
      if (!asset) return new Response('Not found', { status: 404 });
      if (request.method !== 'GET' && request.method !== 'HEAD') return new Response('Method not allowed', { status: 405, headers: { Allow: 'GET, HEAD' } });
      const headers = { 'Content-Type': asset.type, 'Cache-Control': homepage ? 'no-store' : (asset.type.startsWith('text/html') ? 'no-cache' : 'public, max-age=300'), 'X-Content-Type-Options': 'nosniff' };
      if (request.method === 'HEAD') return new Response(null, { headers });
      let bytes = Uint8Array.from(atob(asset.content), c => c.charCodeAt(0));
      const pageHtml = asset.type.startsWith('text/html') ? currentOpportunityHtml(new TextDecoder().decode(bytes)) : null;
      if (!homepage) return new Response(pageHtml ?? bytes, { headers });
      let count;
      try {
        const prefetch = [request.headers.get('purpose'), request.headers.get('sec-purpose')].some(h => h?.toLowerCase().includes('prefetch'));
        if (prefetch) {
          const row = await env.DB.prepare("SELECT total FROM page_visits WHERE page = 'homepage'").first();
          count = row?.total ?? 10;
        } else {
          // Atomic upsert: seed of 10 plus this first visit = 11. Later requests increment once.
          const row = await env.DB.prepare("INSERT INTO page_visits (page, total) VALUES ('homepage', 11) ON CONFLICT(page) DO UPDATE SET total = total + 1 RETURNING total").first();
          count = row.total;
        }
      } catch (error) {
        // Never invent a total if persistence is unavailable.
        count = null;
      }
      const displayed = count === null ? 'Unavailable' : new Intl.NumberFormat('en-US').format(count) + '+';
      const html = pageHtml.replace('data-visit-total>10+</strong>', 'data-visit-total>' + displayed + '</strong>');
      return new Response(html, { headers });
    }
  };
}
