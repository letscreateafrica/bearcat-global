import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve('dist');
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.txt': 'text/plain; charset=utf-8', '.json': 'application/json; charset=utf-8', '.xml': 'application/xml; charset=utf-8' };
const assets = {};
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === 'server' || entry.name === '.openai') continue;
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(file);
    else assets['/' + path.relative(root, file).split(path.sep).join('/')] = { content: fs.readFileSync(file).toString('base64'), type: types[path.extname(file)] || 'application/octet-stream' };
  }
}
walk(root);
fs.mkdirSync('dist/server', { recursive: true });
fs.writeFileSync('dist/server/index.js', fs.readFileSync('worker/index.js', 'utf8') + '\nconst assets = ' + JSON.stringify(assets) + ';\nexport default createWorker(assets);\n');
fs.mkdirSync('dist/.openai', { recursive: true });
fs.copyFileSync('.openai/hosting.json', 'dist/.openai/hosting.json');
fs.cpSync('drizzle', 'dist/.openai/drizzle', { recursive: true });
console.log(JSON.stringify({ worker: 'dist/server/index.js', embeddedPublicAssets: Object.keys(assets).length, database: 'DB' }));
