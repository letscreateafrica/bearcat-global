"""Compose dated publication covers after finalizing content.json."""
import json, pathlib
from PIL import Image, ImageDraw, ImageFont, ImageOps
root=pathlib.Path(__file__).resolve().parents[1]
data=json.loads((root/'content.json').read_text(encoding='utf-8'))
art=Image.open(root/'artwork'/'hero-original.png').convert('RGB')
logo=Image.open(root/'dist'/'assets'/'sbu-bearcat.png').convert('RGBA')
fonts=pathlib.Path('C:/Windows/Fonts')
def font(size,serif=False,bold=False):
    name=('georgiab.ttf' if bold else 'georgia.ttf') if serif else ('arialbd.ttf' if bold else 'arial.ttf')
    return ImageFont.truetype(str(fonts/name),size)
for issue in data['editions']:
    im=Image.new('RGB',(1600,1060),'#291236')
    im.paste(ImageOps.fit(art,(1600,710)),(0,150))
    draw=ImageDraw.Draw(im)
    draw.rectangle((0,0,1600,150),fill='#291236')
    draw.text((55,26),'BEARCAT GLOBAL',font=font(59,True,True),fill='white')
    draw.text((58,98),'Student Rights & Opportunity Brief',font=font(27),fill='#e8d8f0')
    draw.rounded_rectangle((1430,18,1575,134),radius=12,fill='white')
    stamp=ImageOps.contain(logo,(125,100))
    im.paste(stamp,(1440+(125-stamp.width)//2,26+(100-stamp.height)//2),stamp)
    draw.text((1400,48),issue['date'],font=font(30,bold=True),fill='white',anchor='ra')
    draw.text((1400,95),'Logo © Southwest Baptist University',font=font(15),fill='#d9c8e3',anchor='ra')
    draw.rectangle((0,800,1600,1060),fill='#291236')
    draw.text((55,826),'ONGOING WATCH & VERIFIED REFERENCES',font=font(27,bold=True),fill='#e8d8f0')
    draw.text((55,877),data['brand']['tagline'],font=font(41,True),fill='white')
    draw.text((55,939),data['brand']['origin']+'/briefs/'+issue['date']+'/',font=font(23),fill='white')
    draw.text((55,985),'Presentation, not evidence  |  Information, not individual legal advice',font=font(21),fill='#e8d8f0')
    draw.text((55,1024),'Independent publication. Not an official SBU communication.',font=font(19),fill='#cdb9da')
    dest=root/'dist'/issue['poster']['url'].lstrip('/')
    dest.parent.mkdir(parents=True,exist_ok=True)
    im.save(dest,optimize=True)
    print(dest)
