# Bearcat Global

Independent Student Rights & Opportunity Brief for international students at Southwest Baptist University (SBU).

## Public routes

- Homepage: https://sbuglobal.letscreateafrica.chatgpt.site/
- Full dated brief: /briefs/2026-11-12/
- Visual newsletter: /newsletters/2026-11-12/
- Weekly digest: /digests/2026-11-12/
- Searchable archive: /archive/
- Verified policy notices: /policy-alerts/
- SBU contacts, privacy and attribution: /resources/

## Build

Requires Node.js 20+ and Python 3 with Pillow for cover composition. The original illustration and authentic SBU logo are included. No frontend dependencies or account system are required. A Sites-managed D1 database stores the shared homepage visit total.

1. Edit `content.json` using verified primary sources.
2. Run `python artwork/compose_heroes.py` after finalizing issue dates and copy.
3. Run `node build.mjs`.
4. Run `node verify.mjs`.
5. Run `node preview.mjs` for local preview on port 4173.

The cover compositor currently uses Windows Arial and Georgia fonts. Adjust its font paths for another operating system. Previously built assets in `dist/assets` allow rebuilding pages without recomposing artwork.

## Content and publication

Read `EDITORIAL-INSTRUCTIONS.md` before updating. Keep all dated issues and corrections. Full issue, visual newsletter, archive card, download and social preview use the same issue poster path. Each substantive item has a unique story banner containing the unaltered SBU logo and an explicit presentation-not-evidence label. Original illustration source files are not documentary evidence.

The first web edition covers November 10–12, 2026 with separately dated background. The weekly digest covers November 6–12 and identifies the November 9 opposition letter, not the October proposal, as its within-window development. All-jurisdiction coverage is not claimed.

## Attribution and independence

SBU Bearcat logo: downloaded unchanged from https://www.sbuniv.edu/_resources/images/bearcat-head.png on November 12, 2026. It belongs to Southwest Baptist University and identifies the audience; no university endorsement is claimed. Do not imply that inclusion grants downstream trademark rights.

Other editorial imagery was generated for this project and labelled as presentation artwork. Sources and original official documents are linked beside each item. This project contains no private student records, credentials, analytics scripts or third-party trackers. External links have their own privacy policies.

Information, not individual legal advice. No SBU or attorney editorial review is claimed.

## GitHub source

Complete project: https://github.com/letscreateafrica/bearcat-global

## Homepage visit counter

The homepage includes a shared D1-backed aggregate visit counter, initialized from a disclosed baseline of 10. Each homepage GET increments the total atomically; reloads and automated checks count. HEAD, prefetch and asset requests do not count. No visitor identifier, IP or event history is stored by this application. Homepage responses use no-store. Counter state survives publication because it is stored in the existing Site database binding DB.

Run `node build.mjs`, `node build-worker.mjs`, `node verify.mjs`, and `node verify-counter.mjs`. The deployed Worker embeds every existing public asset and preserves all routes. Keep d1: DB and schema migration files; do not restore static-only hosting or reset the counter during routine editions.


## Weekly STEM opportunity desk
Route: /opportunities/. Source: opportunities.json and build-opportunities.mjs. Nine exact graduate STEM program filters; Jobs, Scholarships, Fellowships and Impact News. Homepage counter is now above the dated brief; preserve the live aggregate and immutable D1 schema.

Each Thursday at 06:00 America/Los_Angeles, open original provider pages, verify full eligibility (including international status), exact deadline/stages/timezone, location, funding/pay, application requirements and program relevance. Use Handshake, Google Careers, Microsoft Research, NVIDIA Research, P.E.O. International and ProFellow as discovery sources; verify aggregator leads at the original provider. No missing-deadline, closed, inaccessible or unsupported application listing. News has original publication date and explicit deadline N/A. Do not assume program fit establishes eligibility or sponsorship. Keep conditional restrictions prominent.

Set verifiedAt to the actual review date, reviewDue seven calendar days later, and nextScheduled to the next Thursday. Worker currentOpportunityHtml removes expired/stale cards server-side without JavaScript, including direct /opportunities/index.html. Missing timezone uses conservative deadline-date start UTC, disclosed on page. News also expires when its weekly verification is overdue. Discovery directory stays available during outages. Never update verification dates without reopening the sources. If a run fails, report failure and allow stale gating; do not present the old scan as fresh.

Run node build.mjs, node build-worker.mjs, node verify.mjs, node verify-counter.mjs and node verify-opportunities.mjs. Reuse the same Site, linked automation, source helper and database. Publish and verify the routes, filters and preserved counter. Sync the sanitized full project ZIP plus documentation to GitHub and replace the existing project download. Weekly static content needs a successful cloud research/build/deploy run; saving a schedule alone is not proof of execution.
