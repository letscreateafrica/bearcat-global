# Bearcat Global

Independent Student Rights & Opportunity Brief for African, Pakistani, Chinese and Indian students at Southwest Baptist University.

## Public routes

- Homepage: https://sbuglobal.letscreateafrica.chatgpt.site/
- Full dated brief: /briefs/2026-11-12/
- Visual newsletter: /newsletters/2026-11-12/
- Weekly digest: /digests/2026-11-12/
- Searchable archive: /archive/
- Verified policy notices: /policy-alerts/
- SBU contacts, privacy and attribution: /resources/

## Build

Requires Node.js 20+ and Python 3 with Pillow for cover composition. The original illustration and authentic SBU logo are included. No frontend dependencies, account system or database are required.

1. Edit `content.json` using verified primary sources.
2. Run `python artwork/compose_heroes.py` after finalizing issue dates and copy.
3. Run `node build.mjs`.
4. Run `node verify.mjs`.
5. Run `node preview.mjs` for local preview on port 4173.

The cover compositor currently uses Windows Arial and Georgia fonts. Adjust its font paths for another operating system. Previously built assets in `dist/assets` allow rebuilding pages without recomposing artwork.

## Content and publication

Read `EDITORIAL-INSTRUCTIONS.md` before updating. Keep all dated issues and corrections. Full issue, visual newsletter, archive card, download and social preview use the same issue poster path. Each substantive item has a unique story banner containing the unaltered SBU logo and an explicit presentation-not-evidence label. Original illustration source files are not documentary evidence.

The first web edition covers November 10–12, 2026 with separately dated background. The weekly digest covers November 6–12 and identifies the November 9 opposition letter, not the October proposal, as its within-window development. All-jurisdiction coverage is not claimed.

## Attribution and independence

SBU Bearcat logo: downloaded unchanged from https://www.sbuniv.edu/_resources/images/bearcat-head.png on November 12, 2026. It belongs to Southwest Baptist University and identifies the audience; no university endorsement is claimed. Do not imply that inclusion grants downstream trademark rights.

Other editorial imagery was generated for this project and labelled as presentation artwork. Sources and original official documents are linked beside each item. This project contains no private student records, credentials, analytics scripts or third-party trackers. External links have their own privacy policies.

Information, not individual legal advice. No SBU or attorney editorial review is claimed.

## GitHub source

Complete project: https://github.com/letscreateafrica/bearcat-global
