import assert from 'node:assert/strict';
import fs from 'node:fs';
import {currentOpportunityHtml,createWorker} from './worker/index.js';
const o=JSON.parse(fs.readFileSync('opportunities.json','utf8'));
assert.equal(o.programs.length,9);assert.equal(new Set(o.programs.map(p=>p.id)).size,9);
assert.equal(o.sources.length,6);assert(o.sources.some(s=>s.url==='https://joinhandshake.com/'));
for(const i of o.items){assert(i.sources.length&&i.sources.every(s=>s.url.startsWith('https://')));assert(i.programs.length&&i.programs.every(id=>o.programs.some(p=>p.id===id)));assert(i.eligibility&&i.requirements&&i.international&&i.deadlineText);if(i.category==='Impact News'){assert.equal(i.deadline,null);assert(i.published);}else assert.match(i.deadline,/^\d{4}-\d{2}-\d{2}$/);}
const html=fs.readFileSync('dist/opportunities/index.html','utf8');
const cards=h=>(h.match(/data-opportunity\b/g)||[]).length;
assert.equal(cards(currentOpportunityHtml(html,new Date('2026-11-14T12:00:00Z'))),4);
const deadlineDay=currentOpportunityHtml(html,new Date('2026-11-15T00:00:00Z'));
assert.equal(cards(deadlineDay),3);assert(!deadlineDay.includes('id="zonta-amelia-earhart-2027"'));
const overdue=currentOpportunityHtml(html,new Date('2026-11-20T00:00:00Z'));
assert.equal(cards(overdue),0);assert(!overdue.includes('id="opp-empty" class="panel" hidden'));assert(overdue.includes('Handshake'));
const home=fs.readFileSync('dist/index.html','utf8');assert(home.indexOf('data-visit-total')<home.indexOf('<h1>'));assert.equal((home.match(/data-visit-total/g)||[]).length,1);assert(home.includes('/opportunities/'));
const assets={'/opportunities/index.html':{type:'text/html',content:Buffer.from(html).toString('base64')}};
const response=await createWorker(assets).fetch(new Request('https://example.test/opportunities/'),{});assert.equal(response.status,200);assert((await response.text()).includes('opp-result-count'));
console.log(JSON.stringify({ok:true,programs:9,sourceDirectories:6,verifiedItems:o.items.length,deadlineAndWeeklyExpiry:'server-side',counterBeforeHeading:true}));
