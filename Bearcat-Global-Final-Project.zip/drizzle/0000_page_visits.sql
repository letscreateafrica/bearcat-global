CREATE TABLE `page_visits` (
  `page` text PRIMARY KEY NOT NULL,
  `total` integer DEFAULT 10 NOT NULL
);
